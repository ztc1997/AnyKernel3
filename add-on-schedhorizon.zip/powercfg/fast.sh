#!/system/bin/sh

sh /data/powercfg/reset.sh

echo 20 > /dev/cpuctl/top-app/cpu.uclamp.min
echo max > /dev/cpuctl/top-app/cpu.uclamp.max

echo 10 > /dev/cpuctl/foreground/cpu.uclamp.min
echo 80 > /dev/cpuctl/foreground/cpu.uclamp.max
