#!/system/bin/sh

# $1:value $2:filepaths
lock_val() {
    for p in $2; do
        if [ -f "$p" ]; then
            chown root:root "$p"
            chmod 0666 "$p"
            echo "$1" >"$p"
            chmod 0444 "$p"
        fi
    done
}

# Cluster low-power
lock_val "schedhorizon" /sys/devices/system/cpu/cpufreq/policy0/scaling_governor

# Cluster high-performance
lock_val "schedhorizon" /sys/devices/system/cpu/cpufreq/policy4/scaling_governor

# Cluster prime
lock_val "schedhorizon" /sys/devices/system/cpu/cpufreq/policy7/scaling_governor
