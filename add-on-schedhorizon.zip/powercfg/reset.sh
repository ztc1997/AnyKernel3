#!/system/bin/sh

set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2
  fi
}

for i in $(seq 0 7); do
    set_value 2147483647 /sys/devices/system/cpu/cpu$i/cpufreq/scaling_min_freq_limit
    set_value "sugov_ext" /sys/devices/system/cpu/cpu$i/cpufreq/scaling_governor
    set_value "walt" /sys/devices/system/cpu/cpu$i/cpufreq/scaling_governor
done
