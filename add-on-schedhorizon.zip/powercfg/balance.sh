#!/system/bin/sh

sh /data/powercfg/schedhorizon.sh

echo "0" > /sys/devices/system/cpu/cpufreq/policy0/schedhorizon/efficient_freq
echo "0" > /sys/devices/system/cpu/cpufreq/policy0/schedhorizon/up_delay
echo 1700000 > /sys/devices/system/cpu/cpufreq/policy0/scaling_min_freq_limit

echo "1400000 2000000" > /sys/devices/system/cpu/cpufreq/policy4/schedhorizon/efficient_freq
echo "50 100" > /sys/devices/system/cpu/cpufreq/policy4/schedhorizon/up_delay
echo 2000000 > /sys/devices/system/cpu/cpufreq/policy4/scaling_min_freq_limit

echo "1200000 1800000" > /sys/devices/system/cpu/cpufreq/policy7/schedhorizon/efficient_freq
echo "50 100" > /sys/devices/system/cpu/cpufreq/policy7/schedhorizon/up_delay
echo 1800000 > /sys/devices/system/cpu/cpufreq/policy7/scaling_min_freq_limit

echo 10 > /dev/cpuctl/top-app/cpu.uclamp.min
echo max > /dev/cpuctl/top-app/cpu.uclamp.max

echo 0 > /dev/cpuctl/foreground/cpu.uclamp.min
echo 80 > /dev/cpuctl/foreground/cpu.uclamp.max
