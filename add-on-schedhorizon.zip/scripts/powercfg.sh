#!/system/bin/sh

switch_mode() {
    echo "$1" > /data/cur_powermode.txt
    sh /data/powercfg/$1.sh
}

case $1 in
    "powersave" | "balance" | "performance" | "fast")
        switch_mode $1 ;;

    "init")
        /data/powercfg.sh $(cat /data/cur_powermode.txt) ;;
    
    *) echo "Failed to apply unknown action '$1'." ;;
esac
