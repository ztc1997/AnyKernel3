rm /data/powercfg.sh
rm /data/powercfg.json
rm /data/cur_powermode.txt
rm -r /data/powercfg