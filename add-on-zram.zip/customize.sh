CONF="/data/zram.conf"

get_prop() {
  cat $CONF | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

PREVIOUS_VERSION=$(get_prop VERSION)
if [[ "$PREVIOUS_VERSION" -ge "20240406" ]]; then
  ZRAM_ALGORITHM=$(get_prop ZRAM_ALGORITHM)
  ZRAM_DISKSIZE=$(get_prop ZRAM_DISKSIZE)
  ZSTD_COMPRESSION_LEVEL=$(get_prop ZSTD_COMPRESSION_LEVEL)
fi

if [[ "$PREVIOUS_VERSION" -lt "20240401" ]]; then
  rm /data/zram_recomp.log
fi

if [[ "$ZRAM_ALGORITHM" == "" ]]; then
  ZRAM_ALGORITHM=zstd
fi

if [[ "$ZRAM_DISKSIZE" == "" ]]; then
  ZRAM_DISKSIZE=16G
fi

if [[ "$ZSTD_COMPRESSION_LEVEL" == "" ]]; then
  ZSTD_COMPRESSION_LEVEL=1
fi

echo "# ZRAM 压缩算法，可选 lz4 lzo lzo-rle zstd
ZRAM_ALGORITHM=$ZRAM_ALGORITHM

# ZRAM 大小
ZRAM_DISKSIZE=$ZRAM_DISKSIZE

# ZSTD 压缩级别
ZSTD_COMPRESSION_LEVEL=$ZSTD_COMPRESSION_LEVEL

VERSION=20240406" >$CONF
