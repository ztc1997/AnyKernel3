#!/system/bin/sh

get_prop() {
  cat /data/zram.conf | grep -v '^#' | grep "^$1=" | cut -f2 -d '='
}

set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 >$2
  fi
}

ZRAM_ALGORITHM=$(get_prop ZRAM_ALGORITHM)
ZRAM_DISKSIZE=$(get_prop ZRAM_DISKSIZE)
ZSTD_COMPRESSION_LEVEL=$(get_prop ZSTD_COMPRESSION_LEVEL)

swapoff /dev/block/zram0 >/dev/null
echo 1 >/sys/block/zram0/reset
echo "$ZSTD_COMPRESSION_LEVEL" >/sys/module/zstd/parameters/compression_level
set_value "$ZRAM_ALGORITHM" /sys/block/zram0/comp_algorithm
set_value "$ZRAM_DISKSIZE" /sys/block/zram0/disksize
mkswap /dev/block/zram0
swapon /dev/block/zram0 >/dev/null
set_value 0 /proc/sys/vm/page-cluster
sleep 60
set_value 130 /proc/sys/vm/swappiness
