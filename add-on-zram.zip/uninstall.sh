rm /data/zram.conf
rm /data/zram_recomp.log
